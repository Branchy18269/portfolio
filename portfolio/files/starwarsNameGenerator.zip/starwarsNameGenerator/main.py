# IMPORTANT : you might notice some unusual code below
# Consider these two lines of code:
#     myName = "This is a test"
#     print(myName[2:6])
# This prints out "is i" to the terminal
# Why does it do that?
# the [2:6] isolates a substring of the myName string starting at the third character (index of 2) and ending at the sixth character (but not including it)
# this syntax is used heavily below to isolate the letters needed to generate your Star Wars name

def generateFirstName(firstName, lastName):
    starWarsFirstName = lastName[0:3] + firstName[0:2]
    return starWarsFirstName

def generateLastName(maidenName, town):
    starWarsLastName = maidenName[0:2] + town[0:3]
    return starWarsLastName

def main():
    fname = input("Enter your first name: ")
    lname = input("Enter your last name: ")
    maidenName = input("Enter your mother's maiden name: ")
    homeTown = input("Enter the name of your home town: ")
    nameToStarWarsName(fname, lname, maidenName, homeTown)
    
def nameToStarWarsName(fname, lname, maidenName, homeTown):
    starWarsName = generateFirstName(fname,lname) + " " + generateLastName(maidenName,homeTown)
    print(starWarsName.title())

main()