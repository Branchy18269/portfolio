def getInput(characterList):
    while True:
        myInput = input("Enter Message: ")
        myInput= myInput.lower()
        
        # loop through every letter of myInput
        for letter in myInput:
            # is this letter in the characerList?
            # if (letter in characterList) == False:
            if (letter not in characterList):
                print("INCORRECT CHARACTER ENTERED! PLEASE TRY AGAIN!")
                break
        else:
            return myInput

def encode(userInput, characterList, encodingList):
    # loop though each letter of userInput
    # APPROACH I
    # for n in range(0, len(userInput)):
    #   print(userInput[n])
    
    # APPROACH II
    encodedOutput = ""
    for letter in userInput:
        # print(letter)
        # find the index of the letter in character list
        index = characterList.index(letter)
        # get the value of the letter in encodingList at the same index
        encodedLetter = encodingList[index]
        # print(encodedLetter)
        encodedOutput = encodedOutput + encodedLetter
        
    print("Your Encoded Message is: ", encodedOutput)
        
def decode(userInput, characterList, encodingList):
    decodedOutput = ""
    for letter in userInput:
        # print(letter)
        # find the index of the letter in character list
        index = encodingList.index(letter)
        # get the value of the letter in encodingList at the same index
        decodedLetter = characterList[index]
        # print(encodedLetter)
        decodedOutput = decodedOutput + decodedLetter
        
        
    print("Your Decoded Message is: ", decodedOutput)
        
def main():
    # character and encoding lists
    characterList = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',' ']
    encodingList =  ['b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',' ','a']
    
    # get user input
    while True:
        numInput = input("Would you like to Decode (1) or Encode (2)? ")
        if numInput == "1":
            userInput = getInput(characterList)
            decode(userInput, characterList, encodingList)
            break
        elif numInput == "2":
            userInput = getInput(characterList)
            encode(userInput, characterList, encodingList)
            break

    
main()