def main():
    # for loop to iterate through the range of 99 to 0
    for i in range(99, -1, -1):
        # if i is greater than 1, print the following
        if i > 1:
            print(f"{i} Bottles of Beer on the wall, {i} Bottles of Beer.\nTake one down and pass it around, {i-1} Bottles of Beer on the wall.\n")
        # if i is equal to 1, print the following
        elif i == 1:
            print(f"1 Bottle of Beer on the wall, 1 Bottle of Beer.\nTake it down and pass it around, No more bottles of Beer on the wall.\n")
        # finally we get to finish the song
        else:
            print("No more Bottles of Beer on the wall, No more Bottles of Beer.\nGo to the store and buy some more, 99 Bottles of Beer on the wall.\n")
    
main()