import random

# Function to generate insults
def generate_insults(victim_name, num_insults, num_adjectives):
    adjectives = ["silly", "stupid", "ugly", "lazy", "smelly", "dumb", "annoying", "ridiculous", "clumsy", "weird"]
    nouns = ["goat", "fool", "buffoon", "clown", "loser", "nincompoop"]

    insults = [] # Call back list for Storing insults
    for _ in range(num_insults):
        # Select random adjectives based on the number specified
        selected_adjectives = random.choices(adjectives, k=num_adjectives) # Select random adjectives using random.choices() function using k to keep the number of adjectives specified
        # Select a random noun
        selected_noun = random.choice(nouns) # Select a Random Noun
        # Format the insult
        insult = f"{victim_name} is a " + " ".join(selected_adjectives) + f" {selected_noun}!" # Joining the list of adjectives with a space in between
        insults.append(insult) # Adding the insult to the list of insults
    
    return insults

# Function to get valid input for the victim's name
def get_victim_name():
    while True:
        # Get the users name
        name = input("Enter the victim's name: ").strip() # Remove leading and trailing whitespace to prevent errors
        # Error check for blank value/input from user
        if name:
            return name
        # If the input is blank, print an error message and ask again
        else:
            print("Error: Name cannot be empty. Please enter a valid name.")

# Function to get valid input for the number of insults
def get_num_insults():
    while True:
        try:
            # Get the number of insults from the user
            num_insults = int(input("Enter the number of insults to generate (1 or greater): ")) # Convert the input to an integer
            # Error check for anything that is not a number equal to 1 or greater
            if num_insults >= 1:
                return num_insults
            # Error message for invalid input
            else:
                print("Error: Number of insults must be 1 or greater.")
        # Error check for anything that is not a number
        except ValueError:
            print("Error: Please enter a valid integer.")

# Function to get valid input for the number of adjectives
def get_num_adjectives():
    while True:
        try:
            # Get the number of adjectives from the user
            num_adjectives = int(input("Enter the number of adjectives to include (1, 2, or 3): ")) # Convert the input to an integer
            # Error check for anything that is not a number equal to 1, 2, or 3
            if num_adjectives in [1, 2, 3]:
                return num_adjectives
            # Error check for anything that is not a number equal to 1, 2, or 3
            else:
                print("Error: Number of adjectives must be 1, 2, or 3.")
        # Error check for anything that is not a number
        except ValueError:
            print("Error: Please enter a valid integer.")

# Function to ask user if they want to play again
def play_again():
    while True:
        # Ask the user if they want to play again
        choice = input("Do you want to play again? (y/n): ").strip().lower() # Convert to lowercase to prevent errors and remove any leading or trailing whitespace to prevent any other errors
        # Error check for anything that is not y or n
        if choice in ['y', 'n']:
            return choice
        # If the user enters anything other than y or n, print an error message and ask again
        else:
            print("Error: Please enter 'y' for yes or 'n' for no.")

# Main function to run the application
def main():
    while True:
        victim_name = get_victim_name() # Get the victim's name
        num_insults = get_num_insults() # Get the number of insults
        num_adjectives = get_num_adjectives() # Get the number of adjectives

        insults = generate_insults(victim_name, num_insults, num_adjectives) # Generate the insults

        # Print insults in a different color (for terminal, using ANSI escape codes)
        for insult in insults:
            print(f"\033[93m{insult}\033[0m")  # Yellow color for insults
        # Check for program quit
        if play_again() == 'n':
            print("Thank you for playing!")
            break

# Run the program
main()