# Description: This is a simple math quiz application that generates random math equations for the user to solve. The user is asked to enter the answer to the equation, and the application provides feedback on whether the answer is correct or incorrect. The user can choose to play again or quit the game.
# Import the random module to generate random numbers.
import random
# Function to generate a random math equation.
def generate_equation():
    # Generates a random math equation with two operands and one operator.
    # Returns the equation and the correct answer.
    operands = [random.randint(1, 10) for _ in range(2)]
    # Randomly choose an operator from the list ['+', '-', '*'].
    operator = random.choice(['+', '-', '*'])
    # Generate the equation as a string.
    equation = f"{operands[0]} {operator} {operands[1]}"
    # Evaluate the equation to get the correct answer.
    return equation, eval(equation)

# Function to validate the user input.
def validate_input(user_input):
    # Validate the user input to ensure it is an integer.
    try:
        # Convert the user input to an integer.
        int(user_input)
        # If the conversion is successful, return True.
        return True
    # If the conversion fails, catch the ValueError and return False.
    except ValueError:
        # If the input is not an integer, print an error message.
        print("Invalid input. Please enter an integer.")
        # Return False to indicate that the input is invalid.
        return False
    
# Main function to run the math quiz application.
def main():
    # Main function to run the math quiz application.
    # Infinite loop to keep the game running until the user decides to quit.
    while True:
        # Generate a random math equation and get the correct answer.
        equation, correct_answer = generate_equation()
        # Display the equation and ask the user for an answer.
        print(f"{equation} = ?")
        
        # Validate the user input to ensure it is an integer.
        while True:
            # Get the user's answer and validate it.
            user_input = input("Your answer: ")
            # If the input is valid, convert it to an integer and break the loop.
            if validate_input(user_input):
                # Convert the user's answer to an integer.
                user_answer = int(user_input)
                # Break the loop to proceed with checking the answer.
                break
        # Check if the user's answer is correct and provide feedback.
        if user_answer == correct_answer:
            print("Correct!")
        # If the user's answer is incorrect, provide the correct answer.
        else:
            print(f"Incorrect. The correct answer is 
            {correct_answer}.")
        # Ask the user if they want to play again.
        play_again = input("Do you want to play again? (Press 'n' to quit): ")
        # If the user chooses to quit, exit the loop and end the game.
        if play_again.lower() == 'n':
            print("Thanks for playing!")
            # Exit the loop to end the game.
            break
        
# Run the main function to start the math quiz application.
main()