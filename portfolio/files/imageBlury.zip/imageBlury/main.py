import pathlib
from PIL import Image, ImageFilter

def getInput():
    # get the file name and blur amount from the user
    fileName = input("Enter the name of the file you want to blur: ")
    blurAmount = int(input("Enter the amount of blur you want: "))
    return fileName, blurAmount


def blurImage(fileName, blurAmount,):
    # Open the image
    image = Image.open("images/" + fileName)
    # Apply the blur
    newImage = image.filter(ImageFilter.GaussianBlur(blurAmount))
    return newImage

def newFileName(fileName, newImage):
    # Get the file name without the extension
    name = pathlib.Path(fileName).stem
    # Add the blurred suffix
    blurredName = name + "_blurred.jpg"
    # Save the new image
    newImage.save("images/" + blurredName)



def main():
    fileName, blurAmount = getInput()
    newImage = blurImage(fileName, blurAmount)
    newFileName(fileName, newImage)
    print("The image has been blurred and saved as " + fileName + "_blurred.jpg")
    
main()